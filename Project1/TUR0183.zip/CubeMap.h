﻿#pragma once
#include "Model.h"

class CubeMap : public Model
{
public:
    CubeMap(const float* model, size_t vertexCount, GLuint mode, int first, int count);
    
};
