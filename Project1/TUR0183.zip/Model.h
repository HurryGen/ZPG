#ifndef MODEL_H
#define MODEL_H

#include <GL/glew.h>

class Model {
public:
	Model();
	~Model();
	void draw(GLuint mode, int first, int count);

private:
	GLuint VBO;
	GLuint VAO;

};

#endif
