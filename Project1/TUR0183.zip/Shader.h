#ifndef SHADER_H
#define SHADER_H

#include <GL/glew.h>
#include <string>


class Shader
{
public:
	Shader(const char* vertex_shader,const char* fragment_shader);
	~Shader();

private:
	GLuint vertexShader;
	GLuint fragmentShader;
	GLuint shaderProgram;
};

#endif
