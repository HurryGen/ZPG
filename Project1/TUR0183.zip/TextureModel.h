﻿#pragma once
#include "Model.h"

class TextureModel: public Model
{
public:
    TextureModel(const float* model, size_t vertexCount, GLuint mode, int first, int count);
    void draw() override;
    
    
};
